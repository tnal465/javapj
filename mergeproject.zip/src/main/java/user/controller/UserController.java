package user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import order.model.Order;
import user.service.UserService;
@RequestMapping("/user")
@Controller
public class UserController {
	
	
	@Autowired
	private UserService userService;

	@RequestMapping("")
	public String userInfo(Model model) { // Model 객체를 사용해야 함
	    List<Order> orders = userService.getOrderList();
	    model.addAttribute("orders", orders); // 모델에 데이터 추가
	    return "user"; // user.jsp 또는 user.html로 이동
	}

	
	
	/*
	@RequestMapping("user")
	public String user() {
		return "user";
	}
	
	
    @PostMapping("/save")
    public String saveProfile(@RequestParam String nickname) {
        System.out.println("저장된 닉네임: " + nickname);
        return "redirect:/user/success";
    }

    @GetMapping("/success")
    public String successPage() {
        return "success"; 
    }
    */
}
